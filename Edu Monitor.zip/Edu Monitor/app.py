from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from transformers import pipeline
from datetime import datetime
import base64
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'static/audio'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

sentiment_analyzer = pipeline("sentiment-analysis")

# Models (unchanged)
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(255), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    department = db.Column(db.String(100), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    feedbacks = db.relationship('Feedback', backref='student', lazy=True)
    faculty_feedbacks = db.relationship('FacultyFeedback', backref='student', lazy=True)
    management_feedbacks = db.relationship('ManagementFeedback', backref='student', lazy=True)

class Faculty(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(255), nullable=False)
    faculty_id = db.Column(db.String(20), unique=True, nullable=False, index=True)
    department = db.Column(db.String(100), nullable=False)
    feedbacks = db.relationship('Feedback', backref='faculty', lazy=True)
    faculty_feedbacks = db.relationship('FacultyFeedback', backref='faculty', lazy=True)
    management_feedbacks = db.relationship('ManagementFeedback', backref='faculty', lazy=True)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey('faculty.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=True)
    feedback_text = db.Column(db.Text, nullable=False)
    sentiment_score = db.Column(db.String(20))
    audio_review = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class FacultyFeedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey('faculty.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    feedback_text = db.Column(db.Text, nullable=False)
    audio_review = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class ManagementFeedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'))
    faculty_id = db.Column(db.Integer, db.ForeignKey('faculty.id'))
    infra_rating = db.Column(db.Integer, nullable=False)
    admin_rating = db.Column(db.Integer, nullable=False)
    campus_rating = db.Column(db.Integer, nullable=False)
    support_rating = db.Column(db.Integer, nullable=False)
    audio_feedback = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role')
        name = request.form.get('name')
        password = request.form.get('password')
        hashed_password = generate_password_hash(password)

        try:
            if role == 'student':
                roll_number = request.form.get('roll_number')
                if Student.query.filter_by(roll_number=roll_number).first():
                    flash(f'A student with roll number {roll_number} already exists!')
                    return render_template('register.html')
                
                student = Student(
                    name=name,
                    password=hashed_password,
                    roll_number=roll_number,
                    department=request.form.get('department'),
                    year=int(request.form.get('year')),
                    semester=int(request.form.get('semester'))
                )
                db.session.add(student)
            elif role == 'faculty':
                faculty_id = request.form.get('faculty_id')
                if Faculty.query.filter_by(faculty_id=faculty_id).first():
                    flash(f'A faculty with ID {faculty_id} already exists!')
                    return render_template('register.html')
                
                faculty = Faculty(
                    name=name,
                    password=hashed_password,
                    faculty_id=faculty_id,
                    department=request.form.get('department')
                )
                db.session.add(faculty)
            db.session.commit()
            flash('Registration successful! Please login.')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Registration failed: {str(e)}')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form.get('role')
        username = request.form.get('username')
        password = request.form.get('password')

        if role == 'student':
            user = Student.query.filter_by(roll_number=username).first()
            if user and check_password_hash(user.password, password):
                session['user_id'] = user.id
                session['role'] = 'student'
                return redirect(url_for('student_dashboard', student_id=user.id))
        elif role == 'faculty':
            user = Faculty.query.filter_by(faculty_id=username).first()
            if user and check_password_hash(user.password, password):
                session['user_id'] = user.id
                session['role'] = 'faculty'
                return redirect(url_for('faculty_dashboard', faculty_id=user.id))
        elif role == 'admin' and username == 'admin' and password == 'admin':
            session['role'] = 'admin'
            return redirect(url_for('admin_dashboard'))
        
        flash('Invalid credentials!')
    return render_template('login.html')

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        role = request.form.get('role')
        username = request.form.get('username')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if new_password != confirm_password:
            flash('Passwords do not match!')
            return render_template('forgot_password.html')

        if role == 'student':
            user = Student.query.filter_by(roll_number=username).first()
            if user:
                user.password = generate_password_hash(new_password)
                db.session.commit()
                flash('Password updated successfully! Please login.')
                return redirect(url_for('login'))
        elif role == 'faculty':
            user = Faculty.query.filter_by(faculty_id=username).first()
            if user:
                user.password = generate_password_hash(new_password)
                db.session.commit()
                flash('Password updated successfully! Please login.')
                return redirect(url_for('login'))
        
        flash('User not found!')
        return render_template('forgot_password.html')
    return render_template('forgot_password.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!')
    return redirect(url_for('login'))

@app.route('/student/<int:student_id>', methods=['GET', 'POST'])
def student_dashboard(student_id):
    if 'role' not in session or session['role'] != 'student':
        flash('Please login as a student!')
        return redirect(url_for('login'))
    
    student = Student.query.get_or_404(student_id)
    search_query = request.args.get('search', '').strip()
    
    # Pagination for Faculty list
    faculty_page = request.args.get('faculty_page', 1, type=int)
    faculty_per_page = 5
    faculty_query = Faculty.query.filter(Faculty.name.ilike(f'%{search_query}%') | Faculty.faculty_id.ilike(f'%{search_query}%')) if search_query else Faculty.query
    faculty_pagination = faculty_query.paginate(page=faculty_page, per_page=faculty_per_page, error_out=False)
    faculty = faculty_pagination.items

    # Pagination for Faculty Feedback
    feedback_page = request.args.get('feedback_page', 1, type=int)
    feedback_per_page = 5
    feedback_query = FacultyFeedback.query.filter_by(student_id=student_id)
    feedback_pagination = feedback_query.paginate(page=feedback_page, per_page=feedback_per_page, error_out=False)
    faculty_feedback = feedback_pagination.items

    return render_template('student_dashboard.html', 
                         student=student, 
                         faculty=faculty, 
                         search_query=search_query, 
                         faculty_feedback=faculty_feedback,
                         faculty_pagination=faculty_pagination,
                         feedback_pagination=feedback_pagination)

@app.route('/faculty/<int:faculty_id>', methods=['GET', 'POST'])
def faculty_dashboard(faculty_id):
    if 'role' not in session or session['role'] != 'faculty':
        flash('Please login as a faculty!')
        return redirect(url_for('login'))
    
    faculty = Faculty.query.get_or_404(faculty_id)
    search_query = request.args.get('search', '').strip()
    
    # Pagination for Student list
    student_page = request.args.get('student_page', 1, type=int)
    student_per_page = 5
    student_query = Student.query.filter(Student.name.ilike(f'%{search_query}%') | Student.roll_number.ilike(f'%{search_query}%')) if search_query else Student.query
    student_pagination = student_query.paginate(page=student_page, per_page=student_per_page, error_out=False)
    students = student_pagination.items

    # Pagination for Student Feedback
    feedback_page = request.args.get('feedback_page', 1, type=int)
    feedback_per_page = 5
    feedback_query = Feedback.query.filter_by(faculty_id=faculty_id)
    feedback_pagination = feedback_query.paginate(page=feedback_page, per_page=feedback_per_page, error_out=False)
    student_feedback = feedback_pagination.items

    return render_template('faculty_dashboard.html', 
                         faculty=faculty, 
                         students=students, 
                         search_query=search_query, 
                         student_feedback=student_feedback,
                         student_pagination=student_pagination,
                         feedback_pagination=feedback_pagination)

@app.route('/admin', methods=['GET', 'POST'])
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        flash('Please login as an admin!')
        return redirect(url_for('login'))
    
    # Get filter parameters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    sentiment_filter = request.args.get('sentiment_filter')

    # Base query for student feedback
    student_feedback_query = Feedback.query

    # Apply date filters
    if start_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            student_feedback_query = student_feedback_query.filter(Feedback.timestamp >= start_date)
        except ValueError:
            flash('Invalid start date format. Use YYYY-MM-DD.')
    if end_date:
        try:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            student_feedback_query = student_feedback_query.filter(Feedback.timestamp <= end_date)
        except ValueError:
            flash('Invalid end date format. Use YYYY-MM-DD.')

    # Apply sentiment filter
    if sentiment_filter in ['positive', 'negative']:
        student_feedback_query = student_feedback_query.filter(Feedback.sentiment_score == sentiment_filter)

    # Pagination for Student Feedback
    student_feedback_page = request.args.get('student_feedback_page', 1, type=int)
    student_feedback_per_page = 5
    student_feedback_pagination = student_feedback_query.paginate(page=student_feedback_page, per_page=student_feedback_per_page, error_out=False)
    student_feedbacks = student_feedback_pagination.items

    # Pagination for Faculty Feedback (unchanged)
    faculty_feedback_page = request.args.get('faculty_feedback_page', 1, type=int)
    faculty_feedback_per_page = 5
    faculty_feedback_pagination = FacultyFeedback.query.paginate(page=faculty_feedback_page, per_page=faculty_feedback_per_page, error_out=False)
    faculty_feedbacks = faculty_feedback_pagination.items

    # Pagination for Management Feedback (unchanged)
    management_feedback_page = request.args.get('management_feedback_page', 1, type=int)
    management_feedback_per_page = 5
    management_feedback_pagination = ManagementFeedback.query.paginate(page=management_feedback_page, per_page=management_feedback_per_page, error_out=False)
    management_feedbacks = management_feedback_pagination.items

    return render_template('admin_dashboard.html', 
                         student_feedbacks=student_feedbacks, 
                         faculty_feedbacks=faculty_feedbacks, 
                         management_feedbacks=management_feedbacks,
                         student_feedback_pagination=student_feedback_pagination,
                         faculty_feedback_pagination=faculty_feedback_pagination,
                         management_feedback_pagination=management_feedback_pagination,
                         start_date=start_date,
                         end_date=end_date,
                         sentiment_filter=sentiment_filter)

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    if 'role' not in session or session['role'] != 'student':
        return redirect(url_for('login'))

    student_id = request.form.get('student_id')
    faculty_id = request.form.get('faculty_id')
    rating = int(request.form.get('rating'))
    feedback_text = request.form.get('feedback_text')
    audio_review = request.form.get('audio_review')

    sentiment = sentiment_analyzer(feedback_text)[0]
    sentiment_score = sentiment['label'].lower()  # Standardize to lowercase

    audio_path = None
    if audio_review and audio_review.startswith('data:audio'):
        audio_data = audio_review.split(',')[1]
        audio_bytes = base64.b64decode(audio_data)
        audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f'feedback_{student_id}_{faculty_id}_{datetime.now().timestamp()}.webm')
        with open(audio_path, 'wb') as f:
            f.write(audio_bytes)
        audio_path = f"/{audio_path}"

    feedback = Feedback(
        student_id=student_id,
        faculty_id=faculty_id,
        rating=rating,
        feedback_text=feedback_text,
        sentiment_score=sentiment_score,
        audio_review=audio_path
    )
    db.session.add(feedback)
    db.session.commit()
    flash('Feedback submitted successfully!')
    return redirect(url_for('student_dashboard', student_id=student_id))

@app.route('/submit_faculty_feedback', methods=['POST'])
def submit_faculty_feedback():
    if 'role' not in session or session['role'] != 'faculty':
        return redirect(url_for('login'))

    faculty_id = request.form.get('faculty_id')
    student_id = request.form.get('student_id')
    rating = int(request.form.get('rating'))
    feedback_text = request.form.get('feedback_text')
    audio_review = request.form.get('audio_review')

    audio_path = None
    if audio_review and audio_review.startswith('data:audio'):
        audio_data = audio_review.split(',')[1]
        audio_bytes = base64.b64decode(audio_data)
        audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f'fac_feedback_{faculty_id}_{student_id}_{datetime.now().timestamp()}.webm')
        with open(audio_path, 'wb') as f:
            f.write(audio_bytes)
        audio_path = f"/{audio_path}"

    feedback = FacultyFeedback(
        faculty_id=faculty_id,
        student_id=student_id,
        rating=rating,
        feedback_text=feedback_text,
        audio_review=audio_path
    )
    db.session.add(feedback)
    db.session.commit()
    flash('Faculty feedback submitted successfully!')
    return redirect(url_for('faculty_dashboard', faculty_id=faculty_id))

@app.route('/submit_management_feedback', methods=['POST'])
def submit_management_feedback():
    if 'role' not in session or session['role'] not in ['student', 'faculty']:
        return redirect(url_for('login'))

    student_id = request.form.get('student_id')
    faculty_id = request.form.get('faculty_id')
    infra_rating = int(request.form.get('infra_rating'))
    admin_rating = int(request.form.get('admin_rating'))
    campus_rating = int(request.form.get('campus_rating'))
    support_rating = int(request.form.get('support_rating'))
    audio_feedback = request.form.get('audio_feedback')

    audio_path = None
    if audio_feedback and audio_feedback.startswith('data:audio'):
        audio_data = audio_feedback.split(',')[1]
        audio_bytes = base64.b64decode(audio_data)
        suffix = 'student' if student_id else 'faculty'
        id_value = student_id if student_id else faculty_id
        audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f'mgmt_feedback_{suffix}_{id_value}_{datetime.now().timestamp()}.webm')
        with open(audio_path, 'wb') as f:
            f.write(audio_bytes)
        audio_path = f"/{audio_path}"

    feedback = ManagementFeedback(
        student_id=student_id if student_id else None,
        faculty_id=faculty_id if faculty_id else None,
        infra_rating=infra_rating,
        admin_rating=admin_rating,
        campus_rating=campus_rating,
        support_rating=support_rating,
        audio_feedback=audio_path
    )
    db.session.add(feedback)
    db.session.commit()
    flash('Management feedback submitted successfully!')
    return redirect(request.referrer)

# Ensure existing feedback records have lowercase sentiment scores
with app.app_context():
    feedbacks = Feedback.query.filter_by(rating=None).all()
    for feedback in feedbacks:
        feedback.rating = 0
    feedbacks = Feedback.query.all()
    for feedback in feedbacks:
        if feedback.sentiment_score:
            feedback.sentiment_score = feedback.sentiment_score.lower()
    db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)